import json,glob,re,collections,sys
tot=0;errs=[];infos=[]
for f in sorted(glob.glob('raw/*.json')):
    rows=json.load(open(f)); cid=rows[0]['componenteId']; tot+=len(rows)
    seen={}
    for r in rows:
        i=r['id']
        if not re.fullmatch(r'[a-z0-9-]+-\d+s-\db-\d{2}',i): errs.append(f'{i}: id fora do padrão')
        if not r['titulo'].strip(): errs.append(f'{i}: título vazio')
        if r['categoria']=='aula':
            for k in ('conteudo','objetivos'):
                if not r[k].strip(): infos.append(f"LACUNA NA FONTE {i} ({r['fonte']['arquivo']} p.{r['fonte']['pagina']}): {k} vazio — «{r['titulo'][:45]}»")
        for k in ('titulo','conteudo','objetivos'):
            if r[k].rstrip().endswith('...'): errs.append(f'{i}: {k} truncado (...)')
        key=(r['serie'],r['bimestre'],r['titulo'],r['conteudo'],r['objetivos'])
        if r['categoria']=='aula' and r['conteudo'] and key in seen and not r['complementar']:
            infos.append(f"IGUAL ao {seen[key]}: {i} (mesmo título+conteúdo+objetivos) — conferir se é repetição do material")
        seen.setdefault(key,i)
        for c in r['codigos']:
            if c.startswith('EM13') and not re.fullmatch(r'EM13(LGG|LP|MAT|CNT|CHS|CO|CG|CEX)\d{2,3}|EM13[A-Z]{2,3}\d{2,3}',c): errs.append(f'{i}: código suspeito {c}')
    # contagem por bimestre
    c=collections.Counter((r['serie'],r['bimestre']) for r in rows)
    pass
print('Itens:',tot,'| erros:',len(errs),'| avisos informativos:',len(infos))
for e in errs[:30]: print('ERRO',e)
dups=[x for x in infos if x.startswith('IGUAL')]; gaps=[x for x in infos if x.startswith('LACUNA')]
print('\nLacunas na fonte:',len(gaps)); [print(' ',g) for g in gaps[:12]]
print('\nItens idênticos dentro do bimestre:',len(dups)); [print(' ',d) for d in dups[:8]]
