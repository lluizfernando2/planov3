import pdfplumber, re, json, sys, glob, os, hashlib

HDR = re.compile(r'(\d)\s*ª\s*(?:série\s*)?\|\s*(\d)\s*[°ºo]?\s*bimestre', re.I)
COD = re.compile(r'\bEM13[A-Z]{2,4}\d{2,3}\b|\bEF\d{2}[A-Z]{2}\d{2}\b|\bIFA\s*-\s*[A-Z]+\s*OA\s*\d+\b')

def norm(s):
    if s is None: return ''
    s = s.replace('\u200b','').replace('\xa0',' ')
    s = re.sub(r'[ \t]*\n[ \t]*', ' ', s)
    return re.sub(r'\s{2,}', ' ', s).strip()

def lines_with_pos(page):
    out=[]
    for l in page.extract_text_lines():
        out.append((l['top'], l['text']))
    return out

def extract(path):
    comp=None; rows=[]; warns=[]
    cur=None  # (serie, bim)
    with pdfplumber.open(path) as pdf:
        for pi,page in enumerate(pdf.pages, start=1):
            tabs = page.find_tables()
            tabs_sorted = sorted(tabs, key=lambda t: t.bbox[1])
            lines = lines_with_pos(page)
            if comp is None:
                for _,tx in lines[:3]:
                    if tx.lower().startswith('aprof') or pi==1:
                        comp=tx.strip(); break
            hdrs=[(top,m) for top,tx in lines for m in [HDR.search(tx)] if m]
            events=[('h',top,m) for top,m in hdrs]+[('t',t.bbox[1],t) for t in tabs_sorted]
            events.sort(key=lambda e:e[1])
            for kind,_,obj in events:
                if kind=='h':
                    cur=(int(obj.group(1)), int(obj.group(2)))
                    continue
                if cur is None:
                    warns.append(f'p{pi}: tabela sem cabeçalho de série/bimestre'); continue
                for r in obj.extract():
                    r=[norm(c) for c in r]
                    if len(r)<6: warns.append(f'p{pi}: linha com {len(r)} colunas'); continue
                    if r[1].lower().startswith('título') : continue
                    rows.append(dict(serie=cur[0],bimestre=cur[1],pagina=pi,
                                     marca=r[0],titulo=r[1],conteudo=r[2],objetivos=r[3],
                                     habilidades=r[4],aprendizagem=r[5]))
    # merge continuation rows (sem título)
    merged=[]
    for r in rows:
        if not r['titulo'] and merged and (r['serie'],r['bimestre'])==(merged[-1]['serie'],merged[-1]['bimestre']):
            for k in ('conteudo','objetivos','habilidades','aprendizagem'):
                if r[k]: merged[-1][k]=(merged[-1][k]+' '+r[k]).strip()
            warns.append(f"p{r['pagina']}: linha de continuação unida a '{merged[-1]['titulo'][:40]}'")
        else: merged.append(r)
    return comp, merged, warns

def slug(s): 
    import unicodedata
    s=unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower()
    return re.sub(r'[^a-z0-9]+','-',s).strip('-')

if __name__=='__main__':
    out='/home/claude/imp/raw'; os.makedirs(out,exist_ok=True)
    summary=[]
    for f in sorted(glob.glob('/mnt/user-data/uploads/*.pdf')):
        base=os.path.basename(f)
        comp,rows,warns=extract(f)
        comp_id=slug(os.path.splitext(base)[0])
        ordem={}
        for r in rows:
            k=(r['serie'],r['bimestre']); ordem[k]=ordem.get(k,0)+1
            r['ordem']=ordem[k]
            r['componente']=comp; r['componenteId']=comp_id
            m=r['marca']
            r['aulasOficiais']=[int(x) for x in re.findall(r'\d+',m)] if re.fullmatch(r'\d+(\s*(e|a|-|,)\s*\d+)*',m) else []
            r['aulaOficial']=r['aulasOficiais'][0] if r['aulasOficiais'] else None
            t=r['titulo'].lower()
            r['categoria']=('avaliacao' if re.match(r'avalia',t) else 'nivelamento' if 'nivelamento' in t else 'recuperacao' if re.match(r'recupera',t) else 'aula')
            r['complementar']= bool(re.search(r'compl|^x$', r['marca'], re.I)) or bool(re.search(r'complementar',r['titulo'],re.I))
            r['codigos']=sorted(set(COD.findall(r['habilidades']+' '+r['aprendizagem'])))
            r['fonte']={'arquivo':base,'pagina':r.pop('pagina')}
            r['id']=f"{comp_id}-{r['serie']}s-{r['bimestre']}b-{r['ordem']:02d}"
        json.dump(rows,open(f'{out}/{comp_id}.json','w'),ensure_ascii=False,indent=1)
        per={}
        for r in rows: per[(r['serie'],r['bimestre'])]=per.get((r['serie'],r['bimestre']),0)+1
        summary.append((base,comp,len(rows),dict(sorted(per.items())),warns))
    for s in summary:
        print(s[0],'|',s[1],'|',s[2],'aulas'); print('   ',s[3])
        for w in s[4][:6]: print('    !',w)
