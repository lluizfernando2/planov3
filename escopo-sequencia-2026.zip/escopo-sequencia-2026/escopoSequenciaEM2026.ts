// Adaptador: JSON extraído do "Escopo-Sequência 2026 – Ensino Médio" (PDFs oficiais) -> CurriculumItem.
// Copie escopoSequenciaEM2026.json e este arquivo para src/data/ (requer "resolveJsonModule": true no tsconfig).
// Este arquivo NÃO inventa dados: tudo vem do JSON; cada item carrega `fonte` (arquivo + página do PDF).
import raw from './escopoSequenciaEM2026.json';
import type { CurriculumItem } from '../types';

type Raw = {
  id: string; serie: number; bimestre: number; ordem: number;
  aulaOficial: number | null; aulasOficiais: number[]; categoria: string; complementar: boolean;
  titulo: string; conteudo: string; objetivos: string; habilidades: string; aprendizagem: string;
  componente: string; componenteId: string; codigos: string[]; fonte: { arquivo: string; pagina: number };
};

export const escopoSequenciaEM2026: CurriculumItem[] = (raw as Raw[]).map((r) => ({
  id: r.id,
  ano: `${r.serie}ª Série`,
  bimestre: `${r.bimestre}º Bimestre`,
  aula: String(r.aulaOficial ?? r.ordem),
  titulo: r.titulo,
  conteudo: r.conteudo,
  objetivos: r.objetivos,
  habilidade: r.habilidades,
  aprendizagem: r.aprendizagem,
  disciplina: r.componente,
  habilidadeCodigo: r.codigos.join('; '),
  categoria: r.categoria,          // 'aula' | 'avaliacao' | 'nivelamento' | 'recuperacao'
  complementar: r.complementar,
  ordem: r.ordem,
  fonte: r.fonte,                  // rastreabilidade: PDF de origem + página
}));
