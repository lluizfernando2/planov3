# Escopo-Sequência 2026 – Ensino Médio: dados extraídos

Fonte única: os 14 PDFs oficiais enviados. Nada foi escrito à mão nem gerado por IA; cada item tem `fonte` (arquivo + página).

## Conteúdo

| Componente | Arquivo | Série → nº de aulas |
|---|---|---|
| Aprof. Biologia | Aprof_Biologia.pdf | 3ª: 52 |
| Aprof. Filosofia | Aprof_Filosofia.pdf | 3ª: 52 |
| Aprof. Geografia | Aprof_Geografia.pdf | 3ª: 52 |
| Aprof. Química | Aprof_Quimica.pdf | 3ª: 52 |
| Aprof. Sociologia | Aprof_Sociologia.pdf | 3ª: 52 |
| Arte e Mídias Digitais | Arte_e_Midias_Digitais.pdf | 2ª: 26 |
| Atualidades | Atualidades.pdf | 3ª: 52 |
| Educação Financeira | Educacao_Financeira.pdf | 1ª: 52, 2ª: 52 |
| Empreendedorismo | Empreendedorismo.pdf | 2ª: 26, 3ª: 52 |
| Liderança e Oratória | Lideranca_e_Oratoria.pdf | 2ª: 52 |
| Língua Inglesa | Lingua_Inglesa.pdf | 1ª: 80, 2ª: 80, 3ª: 80 |
| Programação | Programacao.pdf | 2ª: 65, 3ª: 64 |
| Projeto de Vida | Projeto_de_Vida.pdf | 1ª: 26, 2ª: 26, 3ª: 26 |
| Redação e Leitura | Redacao_e_Leitura.pdf | 1ª: 64, 2ª: 64, 3ª: 64 |

**Total: 1211 itens.**

## Como usar

1. Copie `escopoSequenciaEM2026.json` e `escopoSequenciaEM2026.ts` para `src/data/`.
2. Importe `escopoSequenciaEM2026` e junte ao `initialCombinedCurriculumData` no lugar dos stubs.
3. Rode `python3 scripts/extract.py` (lê os PDFs) e `python3 scripts/validate.py` sempre que houver PDF novo.

## Pontos de atenção (da própria fonte)

- A coluna **Aula** vem vazia na maioria dos PDFs: `aula` = ordem na tabela do bimestre. Só Programação traz numeração oficial (inclusive faixas como `15 e 16`).
- 11 campos vazios existem no PDF original (Projeto de Vida, Programação, Inglês); o validador lista cada um.
- Há aulas com mesmo título/conteúdo repetidas no mesmo bimestre (ex.: *Plataforma EF* em Inglês, *Práticas de Leitura* em Redação). É o que o PDF traz.
- Linhas `Avaliação`, `Nivelamento` e `Recuperação` (Programação) têm `categoria` própria e não têm conteúdo por natureza.
- Os nomes em `disciplina` são os títulos dos PDFs (ex.: `Aprof. Sociologia`); ajuste ao mapeamento de componentes do app.
- Falta ainda o **Ensino Fundamental** e a **Formação Geral**: esses PDFs não foram enviados.